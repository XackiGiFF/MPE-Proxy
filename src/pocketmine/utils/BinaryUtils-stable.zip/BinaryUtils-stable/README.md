# PocketMine-BinaryUtils
![CI](https://github.com/pmmp/BinaryUtils/workflows/CI/badge.svg)

Classes and methods for conveniently handling binary data
